import React, { useEffect, useState, useContext } from 'react';
import api from '../api';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const MyPage = () => {
  const [orders, setOrders] = useState([]);
  const [myPosts, setMyPosts] = useState([]);
  const [myComments, setMyComments] = useState([]);
  const [likedPosts, setLikedPosts] = useState([]);
  const { user } = useAuth();

  useEffect(() => {
    if (user && user.memberId) {
      fetchMyOrders();
      fetchMyActivity();
    }
  }, [user]);

  const fetchMyOrders = async () => {
    try {
      const res = await api.get('/market/orders/my', { headers: { 'X-Member-Id': user.memberId } });
      setOrders(res.data.content);
    } catch (err) {
      console.error("주문 내역 조회 실패");
    }
  };

  const fetchMyActivity = async () => {
    console.log("현재 확인된 memberId:", user.memberId);
    try {
      const config = {
        headers: { 'X-Member-Id': user.memberId ,
        'Authorization': `Bearer ${localStorage.getItem('token')}`}
      };

      const [postsRes, commentsRes, likesRes] = await Promise.all([
        api.get('/community/posts/my-posts', config),
        api.get('/community/posts/my-comments', config),
        api.get('/community/posts/my-likes', config)
      ]);

      console.log("데이터: ", commentsRes.data);

      setMyPosts(postsRes.data.content);
      setMyComments(commentsRes.data.content);
      setLikedPosts(likesRes.data.content);
    } catch (err) { console.error("활동 내역 로드 실패"); }
  };

  const handleCancel = async (orderId) => {
    if (!window.confirm("주문을 취소하시겠습니까?")) return;
    try {
      await api.post(`/market/orders/${orderId}/cancel`, {}, {
        headers: { 'X-Member-Id': user.memberId }
      });
      alert("취소 완료!");
      fetchMyOrders();
    } catch (err) {
      alert(err.response?.data?.message || "취소가 불가능한 주문입니다.");
    }
  };

  return (
    <div style={{ padding: '20px', maxWidth: '800px', margin: '0 auto' }}>
      <h1>마이페이지</h1>

      {/* 1. 주문 내역 섹션 */}
      <section style={sectionStyle}>
        <h3>🛍️ 나의 주문 내역</h3>
        {orders.length === 0 ? <p>주문 내역이 없습니다.</p> : (
          <ul style={{ listStyle: 'none', padding: 0 }}>
            {orders.map(o => (
              <li key={o.orderId} style={itemStyle}>
                <span>{o.productName} ({o.totalPrice}P)</span>
                <div>
                  <span style={{ color: o.status === 'CANCELLED' ? 'red' : 'green', marginRight: '10px' }}>{o.status}</span>
                  {o.status !== 'CANCELLED' && (
                    <button onClick={() => handleCancel(o.orderId)}>취소</button>
                  )}
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>

      {/* 2. 내가 쓴 게시글 섹션 */}
      <section style={sectionStyle}>
        <h3>📝 내가 쓴 글 ({myPosts.length})</h3>
        {myPosts.map(post => (
          <div key={post.id} style={itemStyle}>
            <Link to={`/posts/${post.id}`}>{post.title}</Link>
            <span style={{ fontSize: '0.8rem', color: '#999' }}>{post.createdAt}</span>
          </div>
        ))}
      </section>

      {/* 3. 내가 쓴 댓글 섹션 */}
      <section style={sectionStyle}>
        <h3>💬 작성한 댓글 ({myComments.length})</h3>
        {myComments.map(comment => (
          <div key={comment.id} style={itemStyle}>
            <p style={{ margin: 0 }}>{comment.content}</p>
            <Link to={`/posts/${comment.postId}`} style={{ fontSize: '0.75rem', color: '#339af0' }}>원문 보기</Link>
          </div>
        ))}
      </section>

      {/* 4. 좋아요 한 글 섹션 */}
      <section style={sectionStyle}>
        <h3>❤️ 좋아요 한 글 ({likedPosts.length})</h3>
        {likedPosts.map(post => (
          <div key={post.id} style={itemStyle}>
            <Link to={`/posts/${post.id}`}>{post.title}</Link>
          </div>
        ))}
      </section>
    </div>
  );
};

const sectionStyle = { marginBottom: '30px', borderBottom: '1px solid #eee', paddingBottom: '20px' };
const itemStyle = { display: 'flex', justifyContent: 'space-between', padding: '10px 0', borderBottom: '1px dashed #fafafa' };
export default MyPage;